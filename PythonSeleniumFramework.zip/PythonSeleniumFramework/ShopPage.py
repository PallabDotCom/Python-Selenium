from selenium.webdriver.common.by import By

from PageObjects.ConfirmPage import ConfirmPage


class ShopPage:
    def __init__(self, driver):
        self.driver = driver

    ProductNames = (By.XPATH, "//div[@class='card h-100']/div/h4/a")
    ProductAdd = (By.XPATH, "//div[@class='card h-100']/div[2]/button")
    checkoutbutton = (By.CSS_SELECTOR, "a[class*='btn-primary']")

    def ProductNames1(self):
        return self.driver.find_elements(*ShopPage.ProductNames)

    def ProductAdd1(self):
        return self.driver.find_elements(*ShopPage.ProductAdd)

    def checkoutbutton1(self):
        self.driver.find_element(*ShopPage.checkoutbutton).click()
        confirmPage = ConfirmPage(self.driver)
        return confirmPage




