from PageObjects.HomePage import HomePage
from utilities.baseClass import baseClass


class TestOne(baseClass):
    def test_product(self):
        log = self.getLogger()
        homepage = HomePage(self.driver)
        shopPage= homepage.shopItems()

        products = shopPage.ProductNames1()
        addProduct = shopPage.ProductAdd1()

        i = -1
        for product in products:
            i = i+1
            productName = product.text

            if productName == "Nokia Edge":
                addProduct[i].click()

        confirmpage = shopPage.checkoutbutton1()
        log.info(self.driver.find_element_by_xpath("//div[@class='container']/div/div/table/tbody/tr[1]/td[1]/div/div/h4/a").text)

        confirmpage.checkout()
        self.driver.find_element_by_id("country").send_keys("ind")
        self.verifyLinkPresence("India")

        self.driver.find_element_by_link_text("India").click()
        self.driver.find_element_by_xpath("//div[@class='checkbox checkbox-primary']").click()
        self.driver.find_element_by_css_selector("[type='submit']").click()
        successText = self.driver.find_element_by_class_name("alert-success").text

        assert "Success! Thank you!" in successText
        log.info(successText)
        #Screenshot
        self.driver.get_screenshot_as_file("screen.png")
        log.info("screenshot captured in screen.png file")