'''

****** Standard selenium python framework ********


#Create browser invocation fixture in conftest.py
#set baseClass to hold all common utilities
#Inherit base class to all test to remove fixture redundant code
#passing command line option to select browser at run time ( ex command promt - py.test --browser_name chrome)
#Implement page object mechanism
#smart way to return page objects from navigation methods
#creating selenium webdriver custom utilities in base class
#parameterizing webdriver test with multiple test data sets
#Getting data from separate data file and injecting it in fixture runtime.
#implementing logging feature
#automatic screenshot capture in failure
# Package & Files
Page objects - > Files : ConfirmPage , HomePage , ShopPage
Test Data -> File: HomePageData
tests- > Files: conftest , readme, test_HomePage, test_Product ,
logfile/html/screenshot will be generated after run
Utilities -> Files: baseClass

#To get html report in test folder run py.test --html=report.html from command promt.


'''