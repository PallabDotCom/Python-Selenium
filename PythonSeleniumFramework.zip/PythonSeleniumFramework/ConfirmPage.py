from selenium.webdriver.common.by import By


class ConfirmPage:
    def __init__(self, driver):
        self.driver = driver

    checkoutbutton = (By.XPATH , "//button[@class='btn btn-success']")

    def checkout(self):
        self.driver.find_element(*ConfirmPage.checkoutbutton).click()

